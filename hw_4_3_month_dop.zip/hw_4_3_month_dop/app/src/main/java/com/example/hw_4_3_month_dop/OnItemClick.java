package com.example.hw_4_3_month_dop;

public interface OnItemClick {
    void onClick(Planes planes);

}
